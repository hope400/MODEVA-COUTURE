<?php
include '../components/connect.php';
session_start();

// Optional test
if (!$conn) {
  die("❌ Database connection failed: " . mysqli_connect_error());
}

// Optional: secure this page
if (!isset($_SESSION['admin_id'])) {
  $_SESSION['admin_id'] = 1; // Temporary for testing
}

// Handle order status update
if (isset($_POST['update_status'])) {
  $orderId = intval($_POST['order_id']);
  $newStatus = mysqli_real_escape_string($conn, $_POST['status']);
  mysqli_query($conn, "UPDATE orders SET status='$newStatus' WHERE id='$orderId'");
  echo "<script>alert('✅ Order status updated successfully!'); window.location='admin_manage_orders.php';</script>";
  exit;
}

// ✅ FIXED QUERY: combine first_name and last_name
$orders = mysqli_query($conn, "
  SELECT 
    o.*, 
    CONCAT(u.first_name, ' ', u.last_name) AS customer_name 
  FROM orders o
  LEFT JOIN users u ON o.user_id = u.id
  ORDER BY o.order_date DESC
");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Orders | Admin Dashboard</title>
  <link rel="stylesheet" href="css/admin_style.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f8f8f8;
    }

    main {
      max-width: 1100px;
      margin: 150px auto;
      background: #fff;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }

    h1 {
      text-align: center;
      margin-bottom: 25px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      border-bottom: 1px solid #ddd;
      text-align: center;
      padding: 12px;
    }

    th {
      background: #f9f9f9;
      font-weight: 600;
    }

    .status {
      padding: 6px 10px;
      border-radius: 6px;
      font-weight: 500;
      color: #fff;
    }

    .Pending { background: #f0b61f; }
    .Shipped { background: #3498db; }
    .Delivered { background: #27ae60; }

    .update-form select {
      padding: 6px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .update-form button {
      background: #f0b61f;
      border: none;
      color: #fff;
      padding: 6px 14px;
      border-radius: 6px;
      cursor: pointer;
      transition: .3s;
    }

    .update-form button:hover {
      background: #d39c10;
    }

    .view-link {
      background: #3498db;
      color: #fff;
      padding: 6px 14px;
      border-radius: 6px;
      text-decoration: none;
      transition: .3s;
    }

    .view-link:hover {
      background: #2980b9;
    }
  </style>
</head>
<body>

<?php include 'components/admin_header.php'; ?>

<main>
  <h1>Manage Orders</h1>

  <table>
    <thead>
      <tr>
        <th>Order ID</th>
        <th>Customer</th>
        <th>Total</th>
        <th>Status</th>
        <th>Order Date</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($orders) > 0): ?>
        <?php while($o = mysqli_fetch_assoc($orders)): ?>
          <tr>
            <td>#<?= $o['id']; ?></td>
            <td><?= htmlspecialchars($o['customer_name'] ?? 'Guest'); ?></td>
            <td>$<?= number_format($o['total_amount'], 2); ?></td>
            <td><span class="status <?= $o['status']; ?>"><?= $o['status']; ?></span></td>
            <td><?= $o['order_date']; ?></td>
            <td>
              <form method="POST" class="update-form" style="display:inline;">
                <input type="hidden" name="order_id" value="<?= $o['id']; ?>">
                <select name="status">
                  <option value="Pending" <?= $o['status']=='Pending'?'selected':''; ?>>Pending</option>
                  <option value="Shipped" <?= $o['status']=='Shipped'?'selected':''; ?>>Shipped</option>
                  <option value="Delivered" <?= $o['status']=='Delivered'?'selected':''; ?>>Delivered</option>
                </select>
                <button type="submit" name="update_status">Update</button>
              </form>
             
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="6">No orders found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</main>

</body>
</html>
